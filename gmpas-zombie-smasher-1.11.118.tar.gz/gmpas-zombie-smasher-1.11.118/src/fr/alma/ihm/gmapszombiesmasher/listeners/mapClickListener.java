package fr.alma.ihm.gmapszombiesmasher.listeners;

import android.view.View;
import android.view.View.OnClickListener;

public class mapClickListener implements OnClickListener {

	@Override
	public void onClick(View v) {
		System.out.println("4242");
	}

}
