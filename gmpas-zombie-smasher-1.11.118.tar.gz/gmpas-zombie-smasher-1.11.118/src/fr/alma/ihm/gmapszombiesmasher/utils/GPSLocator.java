package fr.alma.ihm.gmapszombiesmasher.utils;

public interface GPSLocator {

	public void setCurrentCenter(GPSCoordinate gps);
}
