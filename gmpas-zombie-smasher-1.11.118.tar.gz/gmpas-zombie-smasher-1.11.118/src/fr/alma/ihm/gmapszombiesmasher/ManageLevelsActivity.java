package fr.alma.ihm.gmapszombiesmasher;

import android.app.Activity;
import android.os.Bundle;

public class ManageLevelsActivity extends Activity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.manage_levels);
		
	}

}
