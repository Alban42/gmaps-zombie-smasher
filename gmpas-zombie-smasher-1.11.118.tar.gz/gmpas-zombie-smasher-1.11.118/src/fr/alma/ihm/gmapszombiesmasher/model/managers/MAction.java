package fr.alma.ihm.gmapszombiesmasher.model.managers;

/**
 * 
 * Action manager. Miaou miaou
 * 
 */
public class MAction implements IManager {

	@Override
	public void update() {
		// TODO Auto-generated method stub

	}

}
