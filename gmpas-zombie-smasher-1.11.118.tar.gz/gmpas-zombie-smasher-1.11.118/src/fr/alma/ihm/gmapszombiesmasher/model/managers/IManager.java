package fr.alma.ihm.gmapszombiesmasher.model.managers;

public interface IManager {

	public void update();
	
}
